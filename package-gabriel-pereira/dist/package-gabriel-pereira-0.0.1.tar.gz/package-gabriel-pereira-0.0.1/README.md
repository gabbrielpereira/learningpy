# package_name

Description. 
The package package_name is used to:
	- Testar a criação de pacotes

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install package-gabriel-pereira

```bash
pip install package-gabriel-pereira
```

## Usage

```python
from package-gabriel-pereira import file1_name
file1_name.my_function()
```

## Author
Gabriel Pereira

## License
[MIT](https://choosealicense.com/licenses/mit/)